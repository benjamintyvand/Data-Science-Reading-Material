from django.http import HttpResponse
from django.template import loader

def color(request):
	#return HttpResponse("Rose is Red")
	template = loader.get_template("base.html")
	return HttpResponse(template.render())