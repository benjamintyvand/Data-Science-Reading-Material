from django.db import models

# Create your models here.
class Rose(models.Model):
    color = models.CharField(max_length=30)
    quantity = models.CharField(max_length=30)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    stock = models.IntegerField()
    available = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.color
