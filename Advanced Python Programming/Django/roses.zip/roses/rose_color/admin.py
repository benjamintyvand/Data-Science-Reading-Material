from django.contrib import admin
from .models import Rose

# Register your models here.
#admin.site.register(Rose)

class RoseAdmin(admin.ModelAdmin):
    list_display = ("color", "quantity", "price", "stock", "available", "created_at", "updated_at")
    list_filter = ("available", "created_at", "updated_at")
    list_editable = ("price", "stock", "available")
    search_fields = ("color",)

admin.site.register(Rose, RoseAdmin)